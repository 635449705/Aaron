﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void label1_Click(object sender, EventArgs e)
        {
        
  


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_CASold.Text = "";
            txt_CBSold.Text= "";
            txt_CCSold.Text = "";
            txt_CARev.Text= "";
            txt_CBRev.Text= "";
            txt_CCRev.Text = "";
            txt_totalRev.Text= "";
        }

        private void btn_CalRev_Click(object sender, EventArgs e)
        {


            double CATickets;
            double CBTickets;
            double CCTickets;
            double totalRev;

            if (txt_CASold.Text != "" && txt_CBSold.Text != "" && txt_CCSold.Text != "");



            {


                CATickets = double.Parse (txt_CASold.Text);
                CBTickets = double.Parse (txt_CBSold.Text);
                CCTickets = double.Parse (txt_CCSold.Text);

                CATickets = CATickets * 15.0;
                CBTickets = CBTickets * 12.0;
                CCTickets = CCTickets * 9.0;

                totalRev = CATickets + CBTickets + CCTickets;

                txt_CARev.Text = CATickets.ToString("C");
                txt_CBRev.Text = CBTickets.ToString("C");
                txt_CCRev.Text = CCTickets.ToString("C");
                txt_totalRev.Text = totalRev.ToString("C");

            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
