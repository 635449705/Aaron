﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_CCSold = new System.Windows.Forms.TextBox();
            this.txt_CBSold = new System.Windows.Forms.TextBox();
            this.txt_CASold = new System.Windows.Forms.TextBox();
            this.txt_CARev = new System.Windows.Forms.TextBox();
            this.txt_CBRev = new System.Windows.Forms.TextBox();
            this.txt_CCRev = new System.Windows.Forms.TextBox();
            this.txt_totalRev = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_CalRev = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_CCSold);
            this.groupBox1.Controls.Add(this.txt_CBSold);
            this.groupBox1.Controls.Add(this.txt_CASold);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(0, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(456, 460);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "tickets sold";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txt_totalRev);
            this.groupBox2.Controls.Add(this.txt_CCRev);
            this.groupBox2.Controls.Add(this.txt_CBRev);
            this.groupBox2.Controls.Add(this.txt_CARev);
            this.groupBox2.Location = new System.Drawing.Point(451, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(432, 460);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Revenue Generated";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(387, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "enter the number of ticket sold for each class of seats";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Class A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Class B ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Class C";
            // 
            // txt_CCSold
            // 
            this.txt_CCSold.Location = new System.Drawing.Point(186, 330);
            this.txt_CCSold.Name = "txt_CCSold";
            this.txt_CCSold.ReadOnly = true;
            this.txt_CCSold.Size = new System.Drawing.Size(173, 26);
            this.txt_CCSold.TabIndex = 1;
            // 
            // txt_CBSold
            // 
            this.txt_CBSold.Location = new System.Drawing.Point(186, 231);
            this.txt_CBSold.Name = "txt_CBSold";
            this.txt_CBSold.ReadOnly = true;
            this.txt_CBSold.Size = new System.Drawing.Size(173, 26);
            this.txt_CBSold.TabIndex = 2;
            // 
            // txt_CASold
            // 
            this.txt_CASold.Location = new System.Drawing.Point(186, 130);
            this.txt_CASold.Name = "txt_CASold";
            this.txt_CASold.ReadOnly = true;
            this.txt_CASold.Size = new System.Drawing.Size(173, 26);
            this.txt_CASold.TabIndex = 3;
            // 
            // txt_CARev
            // 
            this.txt_CARev.Location = new System.Drawing.Point(169, 93);
            this.txt_CARev.Name = "txt_CARev";
            this.txt_CARev.Size = new System.Drawing.Size(134, 26);
            this.txt_CARev.TabIndex = 0;
            // 
            // txt_CBRev
            // 
            this.txt_CBRev.Location = new System.Drawing.Point(169, 164);
            this.txt_CBRev.Name = "txt_CBRev";
            this.txt_CBRev.Size = new System.Drawing.Size(134, 26);
            this.txt_CBRev.TabIndex = 1;
            // 
            // txt_CCRev
            // 
            this.txt_CCRev.Location = new System.Drawing.Point(169, 246);
            this.txt_CCRev.Name = "txt_CCRev";
            this.txt_CCRev.Size = new System.Drawing.Size(134, 26);
            this.txt_CCRev.TabIndex = 2;
            // 
            // txt_totalRev
            // 
            this.txt_totalRev.Location = new System.Drawing.Point(169, 330);
            this.txt_totalRev.Name = "txt_totalRev";
            this.txt_totalRev.ReadOnly = true;
            this.txt_totalRev.Size = new System.Drawing.Size(134, 26);
            this.txt_totalRev.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Class A";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Class B";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Class C";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 336);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Total";
            // 
            // btn_CalRev
            // 
            this.btn_CalRev.Location = new System.Drawing.Point(97, 548);
            this.btn_CalRev.Name = "btn_CalRev";
            this.btn_CalRev.Size = new System.Drawing.Size(155, 93);
            this.btn_CalRev.TabIndex = 1;
            this.btn_CalRev.Text = "Calculate Revenue";
            this.btn_CalRev.UseVisualStyleBackColor = true;
            this.btn_CalRev.Click += new System.EventHandler(this.btn_CalRev_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(327, 548);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(160, 93);
            this.btn_Clear.TabIndex = 2;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(571, 548);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(168, 93);
            this.btn_Exit.TabIndex = 3;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 705);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_CalRev);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "stadium seating";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_CCSold;
        private System.Windows.Forms.TextBox txt_CBSold;
        private System.Windows.Forms.TextBox txt_CASold;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_totalRev;
        private System.Windows.Forms.TextBox txt_CCRev;
        private System.Windows.Forms.TextBox txt_CBRev;
        private System.Windows.Forms.TextBox txt_CARev;
        private System.Windows.Forms.Button btn_CalRev;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Exit;
    }
}

